EN > 
You�ve just downloaded the "Bohemian Typewriter" font (2009) which has been created by Lukas Krakora and is free for non-commercial use only.

If you'd like to use the font commercially please contact me at my email krraaa@yahoo.com to get an information about pricing.

I can add any extra characters or customize the font for purchasers of the commercial license.

Any donation from non-commercial users to my Paypal krraaa@yahoo.com is welcome. 

You can find my other fonts on typewriterfonts.net 

And my socials are facebook.com/typewriterfonts and instagram.com/typewriterfonts

Thank you!

Lukas Krakora


CZ > 
Prave jste si stahli font "Bohemian Typewriter" (2009), ktery byl vytvoren Lukasem Krakorou a je volne ke stazeni a pouziti avsak pouze pro nekomercni ucely.

V pripade zameru vyuzit font komercne me prosim kontaktujte na emailu krraaa@yahoo.com a dozvite se cenu.

V pripade potreby mohu zajemcum o komercni licenci pridat k fontu dalsi znaky, ci jakkoli upravit existujici.

Jakekoliv financni prispevky od nekomercnich uzivatelu na muj Paypal krraaa@yahoo.com jsou vitany.

Me dalsi fonty naleznete na typewriterfonts.net

A moje socialni site jsou facebook.com/typewriterfonts and instagram.com/typewriterfonts

Diky!

Lukas Krakora